package hu.qliqs;

public final class ExampleMod {
    public static final String MOD_ID = "create_tram_additions";

    public static void init() {
        // Write common init code here.
    }
}
